# CV
Resume & Cover letter

To view, clone and compile with:
```bash
pdflatex <filename.tex>
open <filename.pdf>
```
OR
```
make resume # compile and open resume
make cover # compile and open cover
```
